/* بعد نشر Google Apps Script، الصق رابط Web App هنا */
window.BARQ_ORDERS = {
  endpoint: 'https://script.google.com/macros/s/AKfycbyuCs-Lr8PILPiyGRoniZSrWc09w3epS5AV1lUT0cg3fICJWWxR138V7ce5M_sxie6w/exec',
  instapayNumber: '01229353208',
  instapayWhatsapp: '201229353208'
};
