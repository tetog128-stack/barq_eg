// BARQ Supabase public configuration. The publishable key is safe in the browser when RLS is enabled.
window.BARQ_SUPABASE = {
  url: 'https://lnzkufsdxljhnzrdhlfy.supabase.co',
  anonKey: 'sb_publishable_B40rh-s_40h17bk3TEnpGg_AJLXt557'
};
